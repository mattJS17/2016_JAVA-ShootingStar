import java.awt.*;
import javax.swing.*;

public class ExplainationThread extends JPanel implements Runnable {

	private ImageIcon explaination;
	private Image imgExSet, imgExGet;
	private JLabel lblExplaination;
	private int delayTime;
	private Thread upThread;

	public ExplainationThread() {
		setPreferredSize(new Dimension(600, 900));
		setBackground(Color.black);
		setLayout(null);

		upThread = null;
		delayTime = 100;
		upThread = new Thread(this);

		explaination = new ImageIcon("explaination.png");
		imgExSet = explaination.getImage();
		imgExGet = imgExSet.getScaledInstance(600, 900, java.awt.Image.SCALE_SMOOTH);
		explaination.setImage(imgExGet);

		lblExplaination = new JLabel(explaination);
		lblExplaination.setBounds(0, 0, 600, 900);
		add(lblExplaination);
	}



	@Override
	public void run() {
		for (int i = 1; i < 850; i++) {
			System.out.println("adfadfa"+delayTime);
			//lblExplaination.setBounds(0, 850 - i , 600, 900);
			try {
				Thread.sleep(delayTime);

			} catch (Exception e) {

			}
		}
	}
}
